import React from 'react';

function AboutUs () {
    return <div>

        <div className="container-fluid bg-grey">
            <div className="row">
                <div className="col-sm-4">
                    <img src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/school-logo-design-template-1a6eb5e8350bc146f093a8771ba2f077_screen.jpg?ts=1612430062"
                    />

                </div>
                <div className="col-sm-8">
                    <h2>Our Values</h2>
                    <h4><strong>MISSION:</strong> Our mission ..</h4>
                    <p><strong>VISION:</strong> Our vision..</p>
                </div>
            </div>
        </div>





    </div>
}
export default AboutUs;
